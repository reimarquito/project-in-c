var searchData=
[
  ['obterchar_0',['obterChar',['../input_8c.html#ae15b6840f5e86d21d0d01c31b5d25cc0',1,'obterChar(char *msg):&#160;input.c'],['../input_8h.html#ae15b6840f5e86d21d0d01c31b5d25cc0',1,'obterChar(char *msg):&#160;input.c']]],
  ['obtercontadorfxequipamento_1',['obterContadorFXEquipamento',['../equipamentos_8c.html#a58aa6f85b22ebc906f0f9ba37cc93d86',1,'equipamentos.c']]],
  ['obtercontadorfxmanutencao_2',['obterContadorFXManutencao',['../manutencao_8c.html#ae4cdeac51f50a0729f8ec423c947f1e3',1,'manutencao.c']]],
  ['obtercontadorfxutilizador_3',['obterContadorFXUtilizador',['../utilizadores_8c.html#af0adbbc06cc041d3bac85d61bbf55475',1,'utilizadores.c']]],
  ['obterdouble_4',['obterDouble',['../input_8c.html#a21f2b70641e75f55e2bd11550fedd899',1,'obterDouble(double minValor, double maxValor, char *msg):&#160;input.c'],['../input_8h.html#a21f2b70641e75f55e2bd11550fedd899',1,'obterDouble(double minValor, double maxValor, char *msg):&#160;input.c']]],
  ['obterfloat_5',['obterFloat',['../input_8c.html#acf0457ff431a6ac3c752715e778b566e',1,'obterFloat(float minValor, float maxValor, char *msg):&#160;input.c'],['../input_8h.html#acf0457ff431a6ac3c752715e778b566e',1,'obterFloat(float minValor, float maxValor, char *msg):&#160;input.c']]],
  ['obterint_6',['obterInt',['../input_8c.html#a1c16d4a2fbe0b0a0b0f9407f7ff1fe9f',1,'obterInt(int minValor, int maxValor, char *msg):&#160;input.c'],['../input_8h.html#a1c16d4a2fbe0b0a0b0f9407f7ff1fe9f',1,'obterInt(int minValor, int maxValor, char *msg):&#160;input.c']]],
  ['operacional_7',['Operacional',['../equipamentos_8h.html#adbc6fd1c40bcc87f0ffb9a41a4a4155aab6bc5f67368947ee776ceeda953f5b2c',1,'equipamentos.h']]],
  ['ordenarmanutencoespordata_8',['ordenarManutencoesPorData',['../manutencao_8c.html#ad8cb99499903fa95de92491f30a05b79',1,'manutencao.c']]],
  ['outro_9',['Outro',['../equipamentos_8h.html#acaa0814a33d4074ea089f95d4bf9aa85ac58ba030da6e844217eb7bfe0613585f',1,'equipamentos.h']]]
];
