var searchData=
[
  ['sigla_0',['sigla',['../struct_utilizador.html#a23bc5485476d187b41f24dd2366a088d',1,'Utilizador']]]
];
