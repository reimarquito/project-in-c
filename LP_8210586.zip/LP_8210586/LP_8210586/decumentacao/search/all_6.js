var searchData=
[
  ['gerirequipamentos_0',['GerirEquipamentos',['../menus_8c.html#a45e13b9aee367903a4e67d19aa9b14ee',1,'GerirEquipamentos():&#160;menus.c'],['../menus_8h.html#a45e13b9aee367903a4e67d19aa9b14ee',1,'GerirEquipamentos():&#160;menus.c']]],
  ['gerirmanutencoes_1',['GerirManutencoes',['../menus_8c.html#a17012ee950fc41c0e6fba607b9a31af7',1,'GerirManutencoes():&#160;menus.c'],['../menus_8h.html#a17012ee950fc41c0e6fba607b9a31af7',1,'GerirManutencoes():&#160;menus.c']]],
  ['gerirutilizadores_2',['GerirUtilizadores',['../menus_8c.html#a2499bc6ea39964eca1e52e0c3e327802',1,'GerirUtilizadores():&#160;menus.c'],['../menus_8h.html#a2499bc6ea39964eca1e52e0c3e327802',1,'GerirUtilizadores():&#160;menus.c']]]
];
