var searchData=
[
  ['categoria_0',['categoria',['../struct_equipamento.html#a56327ace73e9db74a57d8b4f983613e8',1,'Equipamento']]],
  ['codigo_5futilizador_1',['codigo_utilizador',['../struct_equipamento.html#a1cd04a4134b29c76e57279cea92a0407',1,'Equipamento']]],
  ['contador_2',['contador',['../struct_equipamentos.html#a2c6a3fb7cddd9bd7254692264962b5b3',1,'Equipamentos::contador()'],['../struct_manutencoes.html#a2c6a3fb7cddd9bd7254692264962b5b3',1,'Manutencoes::contador()'],['../struct_utilizadores.html#a2c6a3fb7cddd9bd7254692264962b5b3',1,'Utilizadores::contador()']]]
];
