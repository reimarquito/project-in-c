var searchData=
[
  ['utilizador_0',['Utilizador',['../struct_utilizador.html',1,'']]],
  ['utilizadores_1',['Utilizadores',['../struct_utilizadores.html',1,'']]]
];
