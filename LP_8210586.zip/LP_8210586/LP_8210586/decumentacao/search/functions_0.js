var searchData=
[
  ['apagardadosequipamento_0',['apagarDadosEquipamento',['../equipamentos_8c.html#a095979c2ebdc76319d9153dbf4f8b369',1,'equipamentos.c']]],
  ['apagardadosmanutencao_1',['apagarDadosManutencao',['../manutencao_8c.html#a5c27aa09e4b2179a30d8f940e95dbe33',1,'manutencao.c']]],
  ['apagardadosutilizador_2',['apagarDadosUtilizador',['../utilizadores_8c.html#a936e71faa8d68a4604ceb126a32307a5',1,'utilizadores.c']]],
  ['atualizarcontadorfxequipamento_3',['atualizarContadorFXEquipamento',['../equipamentos_8c.html#a72258c8d90c7e810c7d28f19733cfcd5',1,'equipamentos.c']]],
  ['atualizarcontadorfxmanutencao_4',['atualizarContadorFXManutencao',['../manutencao_8c.html#a310e16619817ae38c109e342f524e9a8',1,'manutencao.c']]],
  ['atualizarcontadorfxutilizador_5',['atualizarContadorFXUtilizador',['../utilizadores_8c.html#a32836085f1ce62a33680ba2968892632',1,'utilizadores.c']]],
  ['atualizarequipamento_6',['atualizarEquipamento',['../equipamentos_8c.html#a4b6a8fe163603988830018977ca62271',1,'equipamentos.c']]],
  ['atualizarequipamentofx_7',['atualizarEquipamentoFX',['../equipamentos_8c.html#a48198ba6cd359c19a3b42e506ffc6357',1,'equipamentos.c']]],
  ['atualizarequipamentos_8',['atualizarEquipamentos',['../equipamentos_8c.html#a9c8d866efb8048f6c28843f908eeb291',1,'atualizarEquipamentos(Equipamentos *equipamentos, char *ficheiro):&#160;equipamentos.c'],['../equipamentos_8h.html#a9c8d866efb8048f6c28843f908eeb291',1,'atualizarEquipamentos(Equipamentos *equipamentos, char *ficheiro):&#160;equipamentos.c']]],
  ['atualizarestadoequipamento_9',['atualizarEstadoequipamento',['../equipamentos_8c.html#adee77dde1003782dac340c18f0981d78',1,'atualizarEstadoequipamento(Equipamentos *equipamentos, char *ficheiro):&#160;equipamentos.c'],['../equipamentos_8h.html#adee77dde1003782dac340c18f0981d78',1,'atualizarEstadoequipamento(Equipamentos *equipamentos, char *ficheiro):&#160;equipamentos.c']]],
  ['atualizarestadoutilizador_10',['atualizarEstadoUtilizador',['../utilizadores_8c.html#a38af9c978911ff2c17bf415d2140e261',1,'atualizarEstadoUtilizador(Utilizadores *utilizadores, char *ficheiro):&#160;utilizadores.c'],['../utilizadores_8h.html#a38af9c978911ff2c17bf415d2140e261',1,'atualizarEstadoUtilizador(Utilizadores *utilizadores, char *ficheiro):&#160;utilizadores.c']]],
  ['atualizarmanutencao_11',['atualizarManutencao',['../manutencao_8c.html#abce7afa95337ecefdee4270054aa2b3b',1,'manutencao.c']]],
  ['atualizarmanutencaofx_12',['atualizarManutencaoFX',['../manutencao_8c.html#a07426741f369c410ae5224dd2a106de7',1,'manutencao.c']]],
  ['atualizarmanutencoes_13',['atualizarManutencoes',['../manutencao_8c.html#a7dc8964c136a8eadfbec22e7623c0d3d',1,'atualizarManutencoes(Manutencoes *manutencoes, char *ficheiro):&#160;manutencao.c'],['../manutencao_8h.html#a7dc8964c136a8eadfbec22e7623c0d3d',1,'atualizarManutencoes(Manutencoes *manutencoes, char *ficheiro):&#160;manutencao.c']]],
  ['atualizarutilizador_14',['atualizarUtilizador',['../utilizadores_8c.html#a00a540eff2a72bc201e04b44fec49d95',1,'utilizadores.c']]],
  ['atualizarutilizadores_15',['atualizarUtilizadores',['../utilizadores_8c.html#a8b38fe109ce2fdc084d3741571860e95',1,'atualizarUtilizadores(Utilizadores *utilizadores, char *ficheiro):&#160;utilizadores.c'],['../utilizadores_8h.html#a8b38fe109ce2fdc084d3741571860e95',1,'atualizarUtilizadores(Utilizadores *utilizadores, char *ficheiro):&#160;utilizadores.c']]],
  ['atualizarutilizadorfx_16',['atualizarUtilizadorFX',['../utilizadores_8c.html#aa08804881f325ceab2e314cc1c5144ec',1,'utilizadores.c']]]
];
