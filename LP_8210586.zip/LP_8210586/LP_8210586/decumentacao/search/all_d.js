var searchData=
[
  ['rato_0',['Rato',['../equipamentos_8h.html#acaa0814a33d4074ea089f95d4bf9aa85a8cadfec56b7892758324899d5a6af36a',1,'equipamentos.h']]],
  ['removerequipamentofx_1',['removerEquipamentoFX',['../equipamentos_8c.html#a05f71f37b11aa4af7c38c79fb98dd1ef',1,'equipamentos.c']]],
  ['removerutilizadores_2',['removerUtilizadores',['../utilizadores_8c.html#aac185f96d125866767f800b653cd42f6',1,'removerUtilizadores(Utilizadores *utilizadores, char *ficheiro):&#160;utilizadores.c'],['../utilizadores_8h.html#aac185f96d125866767f800b653cd42f6',1,'removerUtilizadores(Utilizadores *utilizadores, char *ficheiro):&#160;utilizadores.c']]],
  ['removerutilizadorfx_3',['removerUtilizadorFX',['../utilizadores_8c.html#aa58deba0cba4fc37bd30e8b04b6e06a0',1,'utilizadores.c']]],
  ['router_4',['Router',['../equipamentos_8h.html#acaa0814a33d4074ea089f95d4bf9aa85a31861e9c4dbafdfa3b87d7790f13857e',1,'equipamentos.h']]]
];
