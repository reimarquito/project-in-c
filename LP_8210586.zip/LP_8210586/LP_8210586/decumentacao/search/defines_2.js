var searchData=
[
  ['tam_5fini_5fmanutencao_0',['TAM_INI_MANUTENCAO',['../manutencao_8c.html#aed270580fee4c93f79cb20757c107fb5',1,'manutencao.c']]],
  ['tam_5finiciar_5fequipamento_1',['TAM_INICIAR_EQUIPAMENTO',['../equipamentos_8c.html#a3ca2ee2f48d0e140466355f4d3ed6c89',1,'equipamentos.c']]],
  ['tam_5finiciar_5futilizador_2',['TAM_INICIAR_UTILIZADOR',['../utilizadores_8c.html#ab5088f9ca5526e6ae93a70348080d33d',1,'utilizadores.c']]]
];
