var searchData=
[
  ['utilizadores_5ffile_0',['UTILIZADORES_FILE',['../menus_8c.html#a643f70dc790ba249e3ff4ced2373c61f',1,'menus.c']]]
];
