var searchData=
[
  ['ano_0',['ano',['../struct_data.html#ac404d93cbf0169fd9e89edc17d0c5572',1,'Data']]]
];
