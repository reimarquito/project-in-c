var searchData=
[
  ['tipo_0',['Tipo',['../equipamentos_8h.html#adbc6fd1c40bcc87f0ffb9a41a4a4155a',1,'equipamentos.h']]],
  ['tipo_5futilizador_1',['Tipo_utilizador',['../utilizadores_8h.html#a18ff5d12cd7242dd903e10180d3990c7',1,'utilizadores.h']]]
];
