var searchData=
[
  ['sigla_0',['sigla',['../struct_utilizador.html#a23bc5485476d187b41f24dd2366a088d',1,'Utilizador']]],
  ['switch_1',['Switch',['../equipamentos_8h.html#acaa0814a33d4074ea089f95d4bf9aa85aab57132cff95cd4bb6b65a486c127dfb',1,'equipamentos.h']]]
];
