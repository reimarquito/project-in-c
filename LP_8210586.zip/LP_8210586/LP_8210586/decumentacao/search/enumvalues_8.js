var searchData=
[
  ['rato_0',['Rato',['../equipamentos_8h.html#acaa0814a33d4074ea089f95d4bf9aa85a8cadfec56b7892758324899d5a6af36a',1,'equipamentos.h']]],
  ['router_1',['Router',['../equipamentos_8h.html#acaa0814a33d4074ea089f95d4bf9aa85a31861e9c4dbafdfa3b87d7790f13857e',1,'equipamentos.h']]]
];
