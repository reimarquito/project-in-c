var searchData=
[
  ['carregarequipamentos_0',['carregarEquipamentos',['../equipamentos_8c.html#af803c5357cb56bc24e465f5e45fd17f4',1,'carregarEquipamentos(Equipamentos *equipamentos, char *ficheiro):&#160;equipamentos.c'],['../equipamentos_8h.html#af803c5357cb56bc24e465f5e45fd17f4',1,'carregarEquipamentos(Equipamentos *equipamentos, char *ficheiro):&#160;equipamentos.c']]],
  ['carregarmanutencoes_1',['carregarManutencoes',['../manutencao_8c.html#a20cd3ae29373f97037b446788ce5f8a3',1,'carregarManutencoes(Manutencoes *manutencoes, char *ficheiro):&#160;manutencao.c'],['../manutencao_8h.html#a20cd3ae29373f97037b446788ce5f8a3',1,'carregarManutencoes(Manutencoes *manutencoes, char *ficheiro):&#160;manutencao.c']]],
  ['carregarutilizadores_2',['carregarUtilizadores',['../utilizadores_8c.html#af0c49e2c95743c4255bf0d2aea9321ca',1,'carregarUtilizadores(Utilizadores *utilizadores, char *ficheiro):&#160;utilizadores.c'],['../utilizadores_8h.html#af0c49e2c95743c4255bf0d2aea9321ca',1,'carregarUtilizadores(Utilizadores *utilizadores, char *ficheiro):&#160;utilizadores.c']]],
  ['categoriatostring1_3',['categoriaToString1',['../equipamentos_8h.html#a8258e5be18bff9e3cfc8a5bd53655f94',1,'categoriaToString1(Categoria categoria):&#160;input.c'],['../input_8c.html#a8258e5be18bff9e3cfc8a5bd53655f94',1,'categoriaToString1(Categoria categoria):&#160;input.c']]],
  ['categoriatostring2_4',['categoriaToString2',['../equipamentos_8h.html#a3f4e67f5c6456898ceb53e8da0bae09c',1,'categoriaToString2(Tipo estado):&#160;input.c'],['../input_8c.html#a3f4e67f5c6456898ceb53e8da0bae09c',1,'categoriaToString2(Tipo estado):&#160;input.c']]],
  ['cleaninputbuffer_5',['cleanInputBuffer',['../input_8c.html#a11ac4d3ec555747d95fee8ae7aa18b5d',1,'cleanInputBuffer():&#160;input.c'],['../input_8h.html#a11ac4d3ec555747d95fee8ae7aa18b5d',1,'cleanInputBuffer():&#160;input.c']]],
  ['comparardatas_6',['compararDatas',['../manutencao_8c.html#a47c288249566595bbbb9c9714df3075b',1,'manutencao.c']]]
];
