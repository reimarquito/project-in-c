var searchData=
[
  ['monitor_0',['Monitor',['../equipamentos_8h.html#acaa0814a33d4074ea089f95d4bf9aa85a5bc568dc1dbb5609a4c6d13b307ceb58',1,'equipamentos.h']]]
];
