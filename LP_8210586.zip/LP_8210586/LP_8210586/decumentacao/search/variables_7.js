var searchData=
[
  ['nome_0',['nome',['../struct_utilizador.html#a82dfe76ec9e58c417f619d07299f9851',1,'Utilizador']]],
  ['num_5fmanutencoes_1',['num_manutencoes',['../struct_equipamento.html#a7eed05f0fb7f83822bc26bf366c86f6f',1,'Equipamento']]]
];
