var searchData=
[
  ['para_5freciclagem_0',['Para_Reciclagem',['../equipamentos_8h.html#adbc6fd1c40bcc87f0ffb9a41a4a4155aadde42d9edf604099c9cc9ad5d4476e69',1,'equipamentos.h']]],
  ['portátil_1',['Portátil',['../equipamentos_8h.html#acaa0814a33d4074ea089f95d4bf9aa85a2dc1ca5d53beee8f281bd8b7090e1999',1,'equipamentos.h']]],
  ['projetor_2',['Projetor',['../equipamentos_8h.html#acaa0814a33d4074ea089f95d4bf9aa85a38efe3c594778f164782f2c1e4303e4d',1,'equipamentos.h']]]
];
