var searchData=
[
  ['removerequipamentofx_0',['removerEquipamentoFX',['../equipamentos_8c.html#a05f71f37b11aa4af7c38c79fb98dd1ef',1,'equipamentos.c']]],
  ['removerutilizadores_1',['removerUtilizadores',['../utilizadores_8c.html#aac185f96d125866767f800b653cd42f6',1,'removerUtilizadores(Utilizadores *utilizadores, char *ficheiro):&#160;utilizadores.c'],['../utilizadores_8h.html#aac185f96d125866767f800b653cd42f6',1,'removerUtilizadores(Utilizadores *utilizadores, char *ficheiro):&#160;utilizadores.c']]],
  ['removerutilizadorfx_2',['removerUtilizadorFX',['../utilizadores_8c.html#aa58deba0cba4fc37bd30e8b04b6e06a0',1,'utilizadores.c']]]
];
