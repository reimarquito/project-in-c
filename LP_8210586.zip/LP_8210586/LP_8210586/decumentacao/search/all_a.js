var searchData=
[
  ['não_5foperacional_0',['Não_Operacional',['../equipamentos_8h.html#adbc6fd1c40bcc87f0ffb9a41a4a4155aaf73aa24a6070eef4dbea63d9d94dfaa6',1,'equipamentos.h']]],
  ['nome_1',['nome',['../struct_utilizador.html#a82dfe76ec9e58c417f619d07299f9851',1,'Utilizador']]],
  ['num_5fmanutencoes_2',['num_manutencoes',['../struct_equipamento.html#a7eed05f0fb7f83822bc26bf366c86f6f',1,'Equipamento']]]
];
