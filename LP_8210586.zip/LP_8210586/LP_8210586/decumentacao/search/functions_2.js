var searchData=
[
  ['expandirequipamentos_0',['expandirEquipamentos',['../equipamentos_8c.html#ac6a3505618aaaabeeb99476bcd93f5d0',1,'equipamentos.c']]],
  ['expandirmanutencoes_1',['expandirManutencoes',['../manutencao_8c.html#ae84668b61b8472fb7861686c9afd93ac',1,'manutencao.c']]],
  ['expandirutilizadores_2',['expandirUtilizadores',['../utilizadores_8c.html#accd261bcc8fc9f775b72b21f3ea3ae22',1,'utilizadores.c']]]
];
