var searchData=
[
  ['tamanho_0',['tamanho',['../struct_equipamentos.html#a0a06f50c808099546e057b445cc90c14',1,'Equipamentos::tamanho()'],['../struct_manutencoes.html#a0a06f50c808099546e057b445cc90c14',1,'Manutencoes::tamanho()'],['../struct_utilizadores.html#a0a06f50c808099546e057b445cc90c14',1,'Utilizadores::tamanho()']]],
  ['tipo_1',['tipo',['../struct_utilizador.html#a432c694279c1af091b75cca192d5aa2a',1,'Utilizador']]]
];
