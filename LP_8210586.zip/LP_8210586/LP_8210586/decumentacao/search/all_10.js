var searchData=
[
  ['utilizador_0',['Utilizador',['../struct_utilizador.html',1,'']]],
  ['utilizador_1',['utilizador',['../struct_utilizador.html#a05bab3fa8c1054b6c05bdac7892f96e0',1,'Utilizador']]],
  ['utilizadores_2',['Utilizadores',['../struct_utilizadores.html',1,'']]],
  ['utilizadores_3',['utilizadores',['../struct_utilizadores.html#af96ce49c9066a3b1cfb26ebf2e7deac8',1,'Utilizadores::utilizadores()'],['../menus_8c.html#a6449b9d6ac3acb6a1554237e8f0ebe0c',1,'utilizadores():&#160;menus.c']]],
  ['utilizadores_2ec_4',['utilizadores.c',['../utilizadores_8c.html',1,'']]],
  ['utilizadores_2eh_5',['utilizadores.h',['../utilizadores_8h.html',1,'']]],
  ['utilizadores_5ffile_6',['UTILIZADORES_FILE',['../menus_8c.html#a643f70dc790ba249e3ff4ced2373c61f',1,'menus.c']]]
];
