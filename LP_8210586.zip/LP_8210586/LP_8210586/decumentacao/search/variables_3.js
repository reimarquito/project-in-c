var searchData=
[
  ['equipamentos_0',['equipamentos',['../struct_equipamentos.html#ac19fd5deb13090cbaaa1f96f43958960',1,'Equipamentos::equipamentos()'],['../menus_8c.html#a4c8f17d8d967ce74213b9e00c084ff5e',1,'equipamentos():&#160;menus.c']]],
  ['estado_1',['estado',['../struct_equipamento.html#adf5c5cfdeb747959f17e63fe310c5062',1,'Equipamento']]]
];
