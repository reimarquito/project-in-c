var searchData=
[
  ['funcao_0',['funcao',['../struct_utilizador.html#ab0cb55af6942565d017a41a0a1ff5eee',1,'Utilizador']]]
];
