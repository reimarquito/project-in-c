var searchData=
[
  ['acessório_0',['Acessório',['../equipamentos_8h.html#acaa0814a33d4074ea089f95d4bf9aa85a2e47b3c93f9d481ac5f6ebe9a7518f2f',1,'equipamentos.h']]],
  ['ativo_1',['Ativo',['../utilizadores_8h.html#a18ff5d12cd7242dd903e10180d3990c7af08178ded961ed2e84369120217df80b',1,'utilizadores.h']]]
];
