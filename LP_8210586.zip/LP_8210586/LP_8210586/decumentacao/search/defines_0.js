var searchData=
[
  ['equipamentos_5ffile_0',['EQUIPAMENTOS_FILE',['../menus_8c.html#af48909a8bbb8dcd5747022577ca6a617',1,'menus.c']]],
  ['erro_5flista_5festa_5fcheia_1',['ERRO_LISTA_ESTA_CHEIA',['../equipamentos_8h.html#afc914475bc1e1714c1af19b4a2664c36',1,'ERRO_LISTA_ESTA_CHEIA():&#160;equipamentos.h'],['../manutencao_8h.html#afc914475bc1e1714c1af19b4a2664c36',1,'ERRO_LISTA_ESTA_CHEIA():&#160;manutencao.h'],['../utilizadores_8h.html#afc914475bc1e1714c1af19b4a2664c36',1,'ERRO_LISTA_ESTA_CHEIA():&#160;utilizadores.h']]],
  ['erro_5flista_5festa_5fvazia_2',['ERRO_LISTA_ESTA_VAZIA',['../equipamentos_8h.html#afa382567429144013156601b44540bf3',1,'ERRO_LISTA_ESTA_VAZIA():&#160;equipamentos.h'],['../manutencao_8h.html#afa382567429144013156601b44540bf3',1,'ERRO_LISTA_ESTA_VAZIA():&#160;manutencao.h'],['../utilizadores_8h.html#afa382567429144013156601b44540bf3',1,'ERRO_LISTA_ESTA_VAZIA():&#160;utilizadores.h']]],
  ['erro_5fmanutencao_5fa_5fnao_5fexiste_3',['ERRO_MANUTENCAO_A_NAO_EXISTE',['../manutencao_8h.html#aff1333d349e137e7cea8f276f6030f2d',1,'manutencao.h']]],
  ['erro_5fo_5fequipamento_5fnao_5fexiste_4',['ERRO_O_EQUIPAMENTO_NAO_EXISTE',['../equipamentos_8h.html#a7837cfc2042704b277687d413bff6a56',1,'equipamentos.h']]],
  ['erro_5fo_5futilizador_5fnao_5fexiste_5',['ERRO_O_UTILIZADOR_NAO_EXISTE',['../utilizadores_8h.html#a5dcfdbadde0eec44fcb615ad26de8be3',1,'ERRO_O_UTILIZADOR_NAO_EXISTE():&#160;utilizadores.h'],['../utilizadores_8h.html#a5dcfdbadde0eec44fcb615ad26de8be3',1,'ERRO_O_UTILIZADOR_NAO_EXISTE():&#160;utilizadores.h']]]
];
