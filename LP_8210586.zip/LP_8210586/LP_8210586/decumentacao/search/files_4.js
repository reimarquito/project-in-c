var searchData=
[
  ['utilizadores_2ec_0',['utilizadores.c',['../utilizadores_8c.html',1,'']]],
  ['utilizadores_2eh_1',['utilizadores.h',['../utilizadores_8h.html',1,'']]]
];
