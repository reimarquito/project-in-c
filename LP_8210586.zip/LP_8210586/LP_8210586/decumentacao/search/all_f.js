var searchData=
[
  ['tam_5fini_5fmanutencao_0',['TAM_INI_MANUTENCAO',['../manutencao_8c.html#aed270580fee4c93f79cb20757c107fb5',1,'manutencao.c']]],
  ['tam_5finiciar_5fequipamento_1',['TAM_INICIAR_EQUIPAMENTO',['../equipamentos_8c.html#a3ca2ee2f48d0e140466355f4d3ed6c89',1,'equipamentos.c']]],
  ['tam_5finiciar_5futilizador_2',['TAM_INICIAR_UTILIZADOR',['../utilizadores_8c.html#ab5088f9ca5526e6ae93a70348080d33d',1,'utilizadores.c']]],
  ['tamanho_3',['tamanho',['../struct_equipamentos.html#a0a06f50c808099546e057b445cc90c14',1,'Equipamentos::tamanho()'],['../struct_manutencoes.html#a0a06f50c808099546e057b445cc90c14',1,'Manutencoes::tamanho()'],['../struct_utilizadores.html#a0a06f50c808099546e057b445cc90c14',1,'Utilizadores::tamanho()']]],
  ['tipo_4',['tipo',['../struct_utilizador.html#a432c694279c1af091b75cca192d5aa2a',1,'Utilizador']]],
  ['tipo_5',['Tipo',['../equipamentos_8h.html#adbc6fd1c40bcc87f0ffb9a41a4a4155a',1,'equipamentos.h']]],
  ['tipo_5futilizador_6',['Tipo_utilizador',['../utilizadores_8h.html#a18ff5d12cd7242dd903e10180d3990c7',1,'utilizadores.h']]],
  ['tv_7',['TV',['../equipamentos_8h.html#acaa0814a33d4074ea089f95d4bf9aa85a818aafb4e6e34b988f90964cd884b8a2',1,'equipamentos.h']]]
];
