var searchData=
[
  ['id_5fequipamento_0',['id_equipamento',['../struct_equipamento.html#a0005440d0d05342b0b6a44201921e02c',1,'Equipamento']]],
  ['id_5futilizador_1',['ID_utilizador',['../struct_utilizador.html#a1108f24841f6594b8515ee599ca52b69',1,'Utilizador']]],
  ['idequipamento_2',['idequipamento',['../struct_manutencao.html#a00bde1a58065bb32453130d787d01b06',1,'Manutencao']]],
  ['idmanutencao_3',['idmanutencao',['../struct_manutencao.html#a063ee864f4b8759e4145371936745bd6',1,'Manutencao']]],
  ['idutilizador_4',['idUtilizador',['../struct_manutencao.html#adea5e6535e19095b2909d89cc58f9d5f',1,'Manutencao']]],
  ['informacao_5',['informacao',['../struct_manutencao.html#a89efbe8077d7d5dba97fad06e9a135a4',1,'Manutencao']]]
];
