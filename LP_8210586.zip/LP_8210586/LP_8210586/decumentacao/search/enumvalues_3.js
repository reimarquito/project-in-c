var searchData=
[
  ['impressora_0',['Impressora',['../equipamentos_8h.html#acaa0814a33d4074ea089f95d4bf9aa85a90ba1df72f61d42e8c5044160532a4a5',1,'equipamentos.h']]],
  ['inativo_1',['Inativo',['../utilizadores_8h.html#a18ff5d12cd7242dd903e10180d3990c7a0cbc2715934e3c8f986da37865fb7cc8',1,'utilizadores.h']]]
];
