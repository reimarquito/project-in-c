var searchData=
[
  ['carregarequipamentos_0',['carregarEquipamentos',['../equipamentos_8c.html#af803c5357cb56bc24e465f5e45fd17f4',1,'carregarEquipamentos(Equipamentos *equipamentos, char *ficheiro):&#160;equipamentos.c'],['../equipamentos_8h.html#af803c5357cb56bc24e465f5e45fd17f4',1,'carregarEquipamentos(Equipamentos *equipamentos, char *ficheiro):&#160;equipamentos.c']]],
  ['carregarmanutencoes_1',['carregarManutencoes',['../manutencao_8c.html#a20cd3ae29373f97037b446788ce5f8a3',1,'carregarManutencoes(Manutencoes *manutencoes, char *ficheiro):&#160;manutencao.c'],['../manutencao_8h.html#a20cd3ae29373f97037b446788ce5f8a3',1,'carregarManutencoes(Manutencoes *manutencoes, char *ficheiro):&#160;manutencao.c']]],
  ['carregarutilizadores_2',['carregarUtilizadores',['../utilizadores_8c.html#af0c49e2c95743c4255bf0d2aea9321ca',1,'carregarUtilizadores(Utilizadores *utilizadores, char *ficheiro):&#160;utilizadores.c'],['../utilizadores_8h.html#af0c49e2c95743c4255bf0d2aea9321ca',1,'carregarUtilizadores(Utilizadores *utilizadores, char *ficheiro):&#160;utilizadores.c']]],
  ['categoria_3',['categoria',['../struct_equipamento.html#a56327ace73e9db74a57d8b4f983613e8',1,'Equipamento']]],
  ['categoria_4',['Categoria',['../equipamentos_8h.html#acaa0814a33d4074ea089f95d4bf9aa85',1,'equipamentos.h']]],
  ['categoriatostring1_5',['categoriaToString1',['../equipamentos_8h.html#a8258e5be18bff9e3cfc8a5bd53655f94',1,'categoriaToString1(Categoria categoria):&#160;input.c'],['../input_8c.html#a8258e5be18bff9e3cfc8a5bd53655f94',1,'categoriaToString1(Categoria categoria):&#160;input.c']]],
  ['categoriatostring2_6',['categoriaToString2',['../equipamentos_8h.html#a3f4e67f5c6456898ceb53e8da0bae09c',1,'categoriaToString2(Tipo estado):&#160;input.c'],['../input_8c.html#a3f4e67f5c6456898ceb53e8da0bae09c',1,'categoriaToString2(Tipo estado):&#160;input.c']]],
  ['cleaninputbuffer_7',['cleanInputBuffer',['../input_8c.html#a11ac4d3ec555747d95fee8ae7aa18b5d',1,'cleanInputBuffer():&#160;input.c'],['../input_8h.html#a11ac4d3ec555747d95fee8ae7aa18b5d',1,'cleanInputBuffer():&#160;input.c']]],
  ['codigo_5futilizador_8',['codigo_utilizador',['../struct_equipamento.html#a1cd04a4134b29c76e57279cea92a0407',1,'Equipamento']]],
  ['comparardatas_9',['compararDatas',['../manutencao_8c.html#a47c288249566595bbbb9c9714df3075b',1,'manutencao.c']]],
  ['computador_10',['Computador',['../equipamentos_8h.html#acaa0814a33d4074ea089f95d4bf9aa85a33e8a12e4902ce0426e4e5f3dc759b8f',1,'equipamentos.h']]],
  ['contador_11',['contador',['../struct_equipamentos.html#a2c6a3fb7cddd9bd7254692264962b5b3',1,'Equipamentos::contador()'],['../struct_manutencoes.html#a2c6a3fb7cddd9bd7254692264962b5b3',1,'Manutencoes::contador()'],['../struct_utilizadores.html#a2c6a3fb7cddd9bd7254692264962b5b3',1,'Utilizadores::contador()']]],
  ['controlador_5fde_5facessos_12',['Controlador_de_acessos',['../equipamentos_8h.html#acaa0814a33d4074ea089f95d4bf9aa85a87a7f8bbc183231b7c48b3bed637c9f4',1,'equipamentos.h']]]
];
