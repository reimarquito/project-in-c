var searchData=
[
  ['switch_0',['Switch',['../equipamentos_8h.html#acaa0814a33d4074ea089f95d4bf9aa85aab57132cff95cd4bb6b65a486c127dfb',1,'equipamentos.h']]]
];
