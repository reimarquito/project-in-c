#ifndef MENUS_H
#define MENUS_H

#ifdef __cplusplus
extern "C" {
#endif

#include "input.h"

int principal();
void GerirEquipamentos ();
void GerirUtilizadores();
void GerirManutencoes();

#ifdef __cplusplus
}
#endif

#endif /* MENUS_H */

